from PaloAltoInterface import PaloAlto
import json

class OpenC2Proxy():
    def commandReceived(self, object):
        
        PAinstance = PaloAlto()
        
        action = object.ACTION
        target = json.loads(object.TARGET.replace("u'","\"").replace("'","\""))
        actuator = json.loads(object.ACTUATOR.replace("u'","\"").replace("'","\""))
        modifiers = json.loads(object.MODIFIERS.replace("u'","\"").replace("'","\""))
        
        if action == "DENY":
            IPAddress = target['specifiers']['DestinationSocketAddress']['IP_Address']['Address_Value']
            statusCode, statusName, statusDescription = PAinstance.addIPsToGroup([IPAddress])
        elif action == "ALLOW":
            IPAddress = target['specifiers']['DestinationSocketAddress']['IP_Address']['Address_Value']
            statusCode, statusName, statusDescription = PAinstance.removeIPsFromGroup([IPAddress])
        
