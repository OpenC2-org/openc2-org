from openc2proxy.models import OpenC2Command
from django.contrib import admin

@admin.register(OpenC2Command)

class OpenC2CommandAdmin(admin.ModelAdmin):
    list_display = ('created', 'ACTION','TARGET','ACTUATOR', 'MODIFIERS')
