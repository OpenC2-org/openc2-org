from django.db import models
from OC2Proxy import OpenC2Proxy

class OpenC2Command(models.Model):
    ACTION = models.CharField(max_length=200)
    TARGET = models.CharField(max_length=200)
    ACTUATOR = models.CharField(max_length=200)
    MODIFIERS = models.CharField(max_length=200)
    created = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['created']

    def save(self, *args, **kwargs):

        super(OpenC2Command, self).save(*args, **kwargs)

        OpenC2Commands = OpenC2Command.objects.all()
        
        OC2Instance = OpenC2Proxy()
        with open('log.txt', 'a') as file:
            file.write('\nEnter models.save')
        
            for object in OpenC2Commands:
                lastObject = object
        OC2Instance.commandReceived(lastObject)
        
    def delete(self, *args, **kwargs):

        OpenC2Commands = OpenC2Command.objects.all()
        OpenC2Commands.delete()
