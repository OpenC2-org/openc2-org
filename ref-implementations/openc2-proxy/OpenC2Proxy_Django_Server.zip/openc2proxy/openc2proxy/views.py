from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from openc2proxy.serializers import OpenC2CommandSerializer, UserSerializer, GroupSerializer
from openc2proxy.models import OpenC2Command

class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer

class OpenC2CommandViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows OpenC2 Commands to be viewed or edited.
    queryset = OpenC2Command.objects.all()
    """
    queryset = OpenC2Command.objects.all().order_by('-created')
    serializer_class = OpenC2CommandSerializer
