# Phantom App imports
import phantom.app as phantom

from phantom.base_connector import BaseConnector
from phantom.action_result import ActionResult

# Imports local to this App
from openc2proxy_consts import *

import requests
from bs4 import BeautifulSoup
import re
import json

requests.packages.urllib3.disable_warnings()

# Define the App Class
class OpenC2ProxyConnector(BaseConnector):

    ACTION_ID_TEST_ASSET_CONNECTIVITY = "test_connectivity"
    ACTION_ID_PROCESS_OPENC2_COMMAND = "process_openc2_command"

    def __init__(self):

        # Call the BaseConnectors init first
        super(OpenC2ProxyConnector, self).__init__()

    def initialize(self):

        config = self.get_config()

        # Base URL
        self._base_url = config[OPENC2PROXY_SERVER]
        if (self._base_url.endswith('/')):
            self._base_url = self._base_url[:-1]

        self._host = self._base_url[self._base_url.find('//') + 2:]
        self._headers = {'Content-Type': 'application/json'}
        self._api_uri = '/'

        self.__uuid_regex = re.compile('[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z', re.I)

        return phantom.APP_SUCCESS

    def _make_rest_call(self, endpoint, request_params, action_result, method):

        config = self.get_config()

        username = config[OPENC2PROXY_USERNAME]
        password = config[OPENC2PROXY_PASSWORD]

        # Create the headers
        headers = self._headers
        resp_json = None

        try:
            if (method == "get"):
                r = requests.get(self._base_url + self._api_uri + endpoint, verify=False, auth=(username, password), params=request_params, headers=headers)
            elif (method == "post"):
                r = requests.post(self._base_url + self._api_uri + endpoint, verify=False, auth=(username, password), json=json.loads(request_params), headers=headers)
        except Exception as e:
            return (action_result.set_status(phantom.APP_ERROR, OPENC2PROXY_ERR_SERVER_CONNECTION, e), resp_json)

        # self.debug_print('REST url: {0}'.format(r.url))

        if ((r.status_code != requests.codes.ok) | (r.status_code != 201)):  # pylint: disable=E1101
            try:
                soup = BeautifulSoup(r.text)
                text = soup.get_text()
            except:
                return (action_result.set_status(phantom.APP_ERROR, OPENC2PROXY_ERR_FROM_SERVER, status=r.status_code,
                    detail=r.text), resp_json)
        else:
            return (action_result.set_status(phantom.APP_ERROR, OPENC2PROXY_ERR_FROM_SERVER, status=r.status_code,
                    detail=text), resp_json)

        try:
            resp_json = r.json()
        except Exception as e:
            return (action_result.set_status(phantom.APP_ERROR, OPENC2PROXY_ERR_JSON_PARSE, data=r.text), None)

        return (phantom.APP_SUCCESS, resp_json)

    def _test_connectivity(self, param):

        # Progress
        self.save_progress(OPENC2PROXY_USING_BASE_URL, base_url=self._base_url)

        # Connectivity
        self.save_progress(phantom.APP_PROG_CONNECTING_TO_ELLIPSES, self._host)

        endpoint = ''
        request_params = {'limit': '1'}

        action_result = ActionResult()

        self.save_progress(OPENC2PROXY_MSG_GET_DEVICES_TEST)

        ret_val, response = self._make_rest_call(endpoint, request_params, action_result, "get")

        if (phantom.is_fail(ret_val)):
            self.debug_print(action_result.get_message())
            self.set_status(phantom.APP_ERROR, action_result.get_message())
            self.append_to_message(OPENC2PROXY_ERR_CONNECTIVITY_TEST)
            return phantom.APP_ERROR

        return self.set_status_save_progress(phantom.APP_SUCCESS, OPENC2PROXY_SUCC_CONNECTIVITY_TEST)

    def _process_openc2_command(self, param):

        action_result = self.add_action_result(ActionResult(dict(param)))

        # Progress
        self.save_progress(OPENC2PROXY_USING_BASE_URL, base_url=self._base_url)

        # Connectivity
        self.save_progress(phantom.APP_PROG_CONNECTING_TO_ELLIPSES, self._host)

	config = self.get_config()
	endpoint = ''
	request_params = param[OPENC2PROXY_COMMAND]

        ret_val, response = self._make_rest_call(endpoint, request_params, action_result, "post")

        message = ''

        if (response):
            if ('messages' in response):
                if ('message' in response['messages']):
                    message = "Message from server: {0}".format(response['messages']['message'])
            else:
                if ('errors' in response):
                    details = "An error occurred during an attempt to pass an OpenC2 command to the OpenC2 proxy. Please check the accuracy of this command."
                    return (action_result.set_status(phantom.APP_ERROR, "Error"), response)

        if (phantom.is_fail(ret_val)):
	    action_result.append_to_message(message)
            self.debug_print(action_result.get_message())
            return action_result.get_status()

        details = "Successfully passed an OpenC2 command off to the OpenC2 Proxy!"

        action_result = self.add_action_result(ActionResult(dict(param)))

        return action_result.set_status(phantom.APP_SUCCESS, details)

    def handle_action(self, param):

        ret_val = phantom.APP_SUCCESS

        # Get the action that we are supposed to execute for this connector run
        action_id = self.get_action_identifier()

        self.debug_print("action_id", self.get_action_identifier())

        if (action_id == phantom.ACTION_ID_TEST_ASSET_CONNECTIVITY):
            ret_val = self._test_connectivity(param)
        elif (action_id == self.ACTION_ID_PROCESS_OPENC2_COMMAND):
            ret_val = self._process_openc2_command(param)

        return ret_val

if __name__ == '__main__':

    import sys
    import json
    import pudb
    pudb.set_trace()

    if (len(sys.argv) < 2):
        print "No test json specified as input"
        exit(0)

    with open(sys.argv[1]) as f:
        in_json = f.read()
        in_json = json.loads(in_json)
        print(json.dumps(in_json, indent=4))

        connector = OpenC2ProxyConnector()
        connector.print_progress_message = True
        ret_val = connector._handle_action(json.dumps(in_json), None)
        print json.dumps(json.loads(ret_val), indent=4)

    exit(0)
