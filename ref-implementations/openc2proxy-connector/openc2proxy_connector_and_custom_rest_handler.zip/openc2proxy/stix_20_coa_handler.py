import json
import logging
import uuid
import random
from jsonpath_rw import parse as jp_parse

LOG_FILENAME = '/tmp/Custom_REST_Handler_STIX20_coa.log'
logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
global logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.debug('****************************************')
logger.debug('***  Start logging debug process...  ***')
logger.debug('****************************************')

def handle_request(request):

  logger.debug('HANDLE_REQUEST Function called.')    

  # For this example the incoming request is in JSON format.
  # See the documentation link to download the sample JSON
  # for posting a single container and single artifact.
  post_as_json = json.loads(request.body)


  # The example JSON has "high_level_data" which is the equivalent
  # to a container and within that it has "low_level_data" which is
  # equivalent to an artifact.
  result = []

  # First we gather the low_level_data
  #low_level = post_as_json['high_level_data']['low_level_data']
  #high_level = post_as_json['high_level_data']
  coa_type = {"type": post_as_json["type"]}
  coa_id = {"id": post_as_json["id"]}
  coa_id = {"spec_version": post_as_json["spec_version"]}
  coa_data = {"courses_of_action": post_as_json["courses_of_action"]}
  logger.debug("coa data: " + json.dumps(coa_data))
  coa_observed_data = {"observed_data": post_as_json["observed_data"]}
  logger.debug("observed data: " + json.dumps(coa_observed_data))
  coa_relationships_data = {"relationships": post_as_json["relationships"]}
  logger.debug("relationships: " + json.dumps(coa_relationships_data))
  
  # Create a UUID randomly by using uuid.uuid1(). Normally we would assign the STIX 2.0 COA 'ID'
  # field to this field but for testing purposes we want to make sure each time we test it that the UUID is unique each and every time.
  sdi = uuid.uuid1()
  sdi_str = sdi.urn[9:]

  # Let's try setting source data identifier to a very big random integer
  sdi_biginteger = random.getrandbits(128)
  sdi_bigintegerSTR = str(sdi_biginteger)

  # Let's set the 'cs1' field equal to what the openc2 command should actually look like...
  openc2_command = {}
  coa_action = json.dumps(coa_data["courses_of_action"][0]["name"])
  if (coa_action == '"Block Network Traffic"'):
    openc2_command["ACTION"] = "DENY"
  elif (coa_action == '"Allow Network Traffic"'):
    openc2_command["ACTION"] = "ALLOW"
  elif (coa_action == '"Contain Network Traffic"'):
    openc2_command["ACTION"] = "CONTAIN"

  # Let's set the openc2 target...
  coa_observed_data_target_type = json.dumps(coa_observed_data["observed_data"][0]["cybox"]["objects"][0]["type"])
  target_type = "{\"TARGET\": {\"type\": " + coa_observed_data_target_type + "}}"
  add_target_type = json.loads(target_type)
  openc2_command.update(add_target_type)
  logger.debug("OpenC2 Command after setting target type: " + json.dumps(openc2_command))

  # Let's set the openc2 target specifiers layer 3 protocol...
  target_specifiers_layer3protocol = {"specifiers": {"Layer3Protocol": "IPv4"}}
  openc2_command["TARGET"].update(target_specifiers_layer3protocol)
  logger.debug("OpenC2 Command after setting target specifiers layer 3 protocol: " + json.dumps(openc2_command))
  
  # Let's set the openc2 target specifiers layer 4 protocol...
  target_specifiers_layer4protocol = {"Layer4Protocol": "TCP"}
  openc2_command["TARGET"]["specifiers"].update(target_specifiers_layer4protocol)
  logger.debug("OpenC2 Command after setting target specifiers layer 4 protocol: " + json.dumps(openc2_command))

  # Let's set the rest of the TARGET specifier fields...
  target_specifiers_ssa = {"SourceSocketAddress": { "IP_Address": {"Address_Value": "any"}}}
  openc2_command["TARGET"]["specifiers"].update(target_specifiers_ssa)
  logger.debug("OpenC2 Command after setting source address: " + json.dumps(openc2_command))

  dip = json.dumps(coa_observed_data["observed_data"][0]["cybox"]["objects"][0]["value:"])
  logger.debug("DIP: " + dip)
  target_specifiers_dsa = "{\"DestinationSocketAddress\": {\"IP_Address\": {\"Address_Value\": " + dip + "}}}"
  logger.debug("target specifiers dip: " + target_specifiers_dsa)
  openc2_command["TARGET"]["specifiers"].update(json.loads(target_specifiers_dsa))
  logger.debug("OpenC2 Command after setting destination address: " + json.dumps(openc2_command))

  actuator_type = {"ACTUATOR": {"type": "openc2:network:firewall"}}
  openc2_command.update(actuator_type)
  logger.debug('OpenC2 Command with actuator data: ' + json.dumps(openc2_command))

  actuator_specifiers = {"specifiers": "30"}
  openc2_command["ACTUATOR"].update(actuator_specifiers)

  modifiers = {"MODIFIERS": {"context_ref": 91}}
  openc2_command.update(modifiers)
  logger.debug("Is it done? " + json.dumps(openc2_command))

  # Now set the cs1 field to the openc2 command we just created!
                        
  # In order for a Phantom container to get generated other required fields need to be set...
  coa_data["name"] = "OpenC2 Command - " + coa_action
  coa_data["source_data_identifier"] = sdi_bigintegerSTR
  coa_data["containname"] = "STIX 2.0 Courses of Action" 
  coa_data["asset_id"] = "5"
  coa_data["status"] = "new"
  coa_data["label"] = json.dumps(coa_data["courses_of_action"][0]["id"])
  coa_data["due_time"] = "2016-01-14T21:54:39.517382Z"
  coa_data["end_time"] = "2016-01-14T21:54:39.517555Z"
  coa_data["ingest_connector_id"] = 437614
  #coa_data["data"] = {"data_field1": "BGhXm6wizmLjt"}
  coa_data["data"] = openc2_command
  coa_data["start_time"] = "2016-01-14T21:54:39.517955Z"
  coa_data["severity"] = "medium"
  logger.debug('Courses of Action data: ' + json.dumps(coa_data))

  #target_data = {"TARGET": post_as_json['TARGET']}
  # In order for a Phantom artifact to get generated the following fields need to set as well...
  coa_observed_data["name"] = "OpenC2 Command - " + coa_action
  coa_observed_data["asset_id"] = 601925
  coa_observed_data["cef"] = {"requestClientApplication": "",
                      "destinationAddress": "",
                      "deviceFacility": "",
                      "deviceExternalId": "",
                      "cn2Label": "",
                      "deviceCustomDate1": "",
                      "deviceCustomDate2": "",
                      "cs1": openc2_command,
                      "deviceCustomNumber3Label": "",
                      "destinationDnsDomain": "",
                      "destinationUserName": "",
                      "fileHash": "8b317b683d052efda16ab03c68ae2dee"
                     }
  coa_observed_data["severity"] = "medium"
  coa_observed_data["data"] = openc2_command
  coa_observed_data["start_time"] = "2016-01-14T21:54:39.762095Z"
  coa_observed_data["source_data_identifier"] = sdi_bigintegerSTR
  coa_observed_data["label"] = "event"
  coa_observed_data["end_time"] = "2016-01-14T21:54:39.762530Z"
  coa_observed_data["ingest_connector_id"] = 796153
  coa_observed_data["type"] = coa_observed_data["observed_data"][0]["type"]
  logger.debug('COA Observed data: ' + json.dumps(coa_observed_data))
  coa_observed_data["openc2command"] = json.dumps(openc2_command)

  coa_relationships_data = post_as_json['relationships']
  logger.debug('Relationships data: ' + json.dumps(coa_relationships_data))

  # We remove low_level_data (artifact) from the container data
  container = coa_data
  logger.debug('Container: ' + json.dumps(container))
  
  # You can post multiple artifacts by adding them to the list
  # in this case, we only have one artifact in our example.
  artifact = [coa_observed_data]
  logger.debug('Artifact: ' + json.dumps(artifact))
  #artifact.append(json.dumps([coa_relationships_data]))
  logger.debug('Artifact after adding other data: ' + json.dumps(artifact))
  
  # Result is a list, containing a dictionary of 1 container and
  # potentially multiple artifacts. Potentially you could add
  # multiple containers with multiple artifacts by appending to
  # this list.
  result.append({
    'container': container,
    'artifacts': artifact
  })
      
  return result

