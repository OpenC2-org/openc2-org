#!/usr/bin/python2.7
# Phantom App imports
import phantom.app as phantom

from phantom.base_connector import BaseConnector
from phantom.action_result import ActionResult

# Imports local to this App
from openc2forwarder_consts import *

import requests
from bs4 import BeautifulSoup
import re
import simplejson as json
import xmltodict

requests.packages.urllib3.disable_warnings()


# Define the App Class
class OpenC2Forwarder(BaseConnector):

    ACTION_ID_FORWARD_OPENC2_COMMAND = "forward_openc2_command"

    def __init__(self):

        # Call the BaseConnectors init first
        super(OpenC2Forwarder, self).__init__()

    def initialize(self):

        config = self.get_config()

        # Base URL
        self._base_url = config[OPENC2FORWARDER_URL]
        if (self._base_url.endswith('/')):
            self._base_url = self._base_url[:-1]

        self._host = self._base_url[self._base_url.find('//') + 2:]
        self._headers = {'Content-Type': 'application/json'}
        self._api_uri = '/api/v1'

        self.__uuid_regex = re.compile('[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}\Z', re.I)

        return phantom.APP_SUCCESS

    def _make_rest_call(self, endpoint, request_params, action_result, method):

        config = self.get_config()

        username = config[OPENC2FORWARDER_USERNAME]
        password = config[OPENC2FORWARDER_PASSWORD]
	
	req_json = None
        # Create the headers
        headers = self._headers
        # For a 'test connectivity' action we don't need request params...
	if (request_params != None):
	    try:
	    	req_json = json.loads(request_params)
	    except ValueError, e:
		#req_json = xmltodict.parse(request_params)
		req_xml = request_params
        
	resp_json = None

        try:
	     if (method == "get"):
                r = requests.get(endpoint, verify=False, auth=(username, password))
		# Since Phantom Cyber doesn't really have a test connection to another Phantom Cyber REST ingest we'll just see if we can 
		# connect via a 'get' call to the ip address by itself...
		if (r.status_code == requests.codes.ok):
		    return (phantom.APP_SUCCESS, None)
             elif (method == "post"):
		if (req_json == None):
		     r = requests.post(endpoint, verify=False, auth=(username, password), params=req_xml, headers={'Content-Type': 'application/xml'})
		     #self.debug_print("Result of POST to Ingest Server: " + r.status_code) # this is 400
		     # Dump the content also
		     #self.debug_print(r.text.replace('{', '-').replace('}', '-'))
                else: 
                     r = requests.post(endpoint, verify=False, auth=(username, password), json=req_json, headers=headers)
		     #self.debug_print(r.status_code) # this is 400
		     # Dump the content also
		     #self.debug_print(r.text.replace('{', '-').replace('}', '-'))
        except Exception as e:
	    self.debug_print("POST to Ingest Server Exception: " + r.text.replace('{', '-').replace('}', '-'))
            return (action_result.set_status(phantom.APP_ERROR, OPENC2FORWARDER_ERR_SERVER_CONNECTION, e), resp_json)

        if (r.status_code != requests.codes.ok):  # pylint: disable=E1101
            try:
                soup = BeautifulSoup(r.text)
                text = soup.get_text()
		self.debug_print("Text of failure: " + text)
            except:
                return (action_result.set_status(phantom.APP_ERROR, OPENC2FORWARDER_ERR_FROM_SERVER, status=r.status_code, detail=r.text), resp_json)
            else:
                return (action_result.set_status(phantom.APP_ERROR, OPENC2FORWARDER_ERR_FROM_SERVER, status=r.status_code, detail=text), resp_json)
	
        try:
            resp_json = r.json()
        except Exception as e:
            return (action_result.set_status(phantom.APP_ERROR, OPENC2FORWARDER_ERR_JSON_PARSE, data=r.text), None)

        return (phantom.APP_SUCCESS, resp_json)

    def _test_connectivity(self, param):

        # Progress
        self.save_progress(OPENC2FORWARDER_USING_BASE_URL, base_url=self._base_url)

        # Connectivity
        self.save_progress(phantom.APP_PROG_CONNECTING_TO_ELLIPSES, self._host)

        endpoint = 'https://192.168.0.36/'
	
	request_params = None 

        action_result = ActionResult()

        ret_val, response = self._make_rest_call(endpoint, request_params, action_result, "get")

        if (phantom.is_fail(ret_val)):
            self.debug_print(action_result.get_message())
            self.set_status(phantom.APP_ERROR, action_result.get_message())
            self.append_to_message(OPENC2FORWARDER_ERR_CONNECTIVITY_TEST)
            return phantom.APP_ERROR

        return self.set_status_save_progress(phantom.APP_SUCCESS, OPENC2FORWARDER_SUCC_CONNECTIVITY_TEST)

    def _forward_openc2_command(self, param):

        action_result = self.add_action_result(ActionResult(dict(param)))

        # Progress
        self.save_progress(OPENC2FORWARDER_USING_BASE_URL, base_url=self._base_url)

        # Connectivity
        self.save_progress(phantom.APP_PROG_CONNECTING_TO_ELLIPSES, self._host)

        #endpoint = '/dm/devices/lock/{0}'.format(param[OPENC2FORWARDER_JSON_UUID])
        #reason = param.get(OPENC2FORWARDER_JSON_REASON, '')
        #reason += ". " if (reason) else ""
        #reason += "Locked via Phantom"
        #request_params = {'reason': reason}
	config = self.get_config()

	endpoint = config[OPENC2FORWARDER_URL]
	request_params = param[OPENC2FORWARDER_COMMAND]

        ret_val, response = self._make_rest_call(endpoint, request_params, action_result, "post")
        #self.debug_print("Result of POST to Ingest Server: " + ret_val.status_code) # this is 400
        # Dump the content also
        #self.debug_print(ret_val.text.replace('{', '-').replace('}', '-'))

        message = ''

        if (response):
            if ('messages' in response):
                if ('message' in response['messages']):
                    message = "Message from server: {0}".format(response['messages']['message'])

        if (phantom.is_fail(ret_val)):
            action_result.append_to_message(message)
            self.debug_print("Result of POST: " + action_result.get_message())
            return action_result.get_status()

        return action_result.set_status(phantom.APP_SUCCESS, message)

    def handle_action(self, param):

        ret_val = phantom.APP_SUCCESS

        # Get the action that we are supposed to execute for this connector run
        action_id = self.get_action_identifier()

        self.debug_print("action_id", self.get_action_identifier())

        if (action_id == phantom.ACTION_ID_TEST_ASSET_CONNECTIVITY):
            ret_val = self._test_connectivity(param)
        elif (action_id == self.ACTION_ID_FORWARD_OPENC2_COMMAND):
            ret_val = self._forward_openc2_command(param)

        return ret_val

if __name__ == '__main__':

    import sys
    import json
    import pudb
    pudb.set_trace()

    if (len(sys.argv) < 2):
        print "No test json specified as input"
        exit(0)

    with open(sys.argv[1]) as f:
        in_json = f.read()
        in_json = json.loads(in_json)
        print(json.dumps(in_json, indent=4))

        connector = OpenC2Forwarder()
        connector.print_progress_message = True
        ret_val = connector._handle_action(json.dumps(in_json), None)
        print json.dumps(json.loads(ret_val), indent=4)

    exit(0)
